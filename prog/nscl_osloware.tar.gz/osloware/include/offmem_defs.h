#define  PERMS 0666			/* ReadWrite for all */
#define  SHAREDMEM_KEY		5600	/* Identifies shared memory set */
#define  MESSAGE_KEY		5700	/* Shared memory segment for message box */

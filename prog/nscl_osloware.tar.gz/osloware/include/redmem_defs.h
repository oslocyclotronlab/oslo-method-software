#define  PERMS 0666			/* ReadWrite for all */
#define  SHAREDMEM_KEY		6000	/* Identifies shared memory set */
#define  MESSAGE_KEY		6100	/* Shared memory segment for message box */

An example how to run the Shape method for two diagonals of the first-generation matrix (fg). Here, we have spin 0+ and 2+ for the diagonals D1 and D2, respectively. In this case we assume that the (p,p) reaction populates only a part of the total spin-distribution of the nucleus. This results in an average level density at Ex = Sn of 22% of the total level density according to the measured average level spacing D0 from l=0 neutron capture on 143Nd.

1. Compile diablo.c and run the executable. 
2. Answer with default values, which is tuned for this example and try to understand what you are doing.
3. Install root from CERN in order to run the cpp scripts.
4. Look at the figures and try to understand what happened. It is important to define the limits for the two diagonals very accurate. There are some outputs for the diablo_plot_144nd.cpp script that tells you how well the diagonals are described.

Good Luck!